# Personal Website

This is a [website](http://jareddyreson.com) I have written in Python using Flask as the back-end and is served using AWS Elastic Beanstalk

# External Links

- [Flask Application Walkthrough](https://www.youtube.com/playlist?list=PL-osiE80TeTs4UjLw5MM6OjgkjFeUxCYH)
- [Frozen Flask PIP Page](https://pythonhosted.org/Frozen-Flask/)
  - [Problems with Frozen Flask](https://www.reddit.com/r/flask/comments/335cyi/a_problem_with_frozenflask/)
  - [Frozen Flask Script Idea](https://nicolas.perriault.net/code/2012/dead-easy-yet-powerful-static-website-generator-with-flask/) 
