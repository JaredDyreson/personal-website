# Personal Website

This is a [website](http://jareddyreson.com) I have written in Python using Flask as the back-end and is served using AWS Elastic Beanstalk

# External Links

- [Flask Application Walkthrough](https://www.youtube.com/playlist?list=PL-osiE80TeTs4UjLw5MM6OjgkjFeUxCYH)
